from rpython.translator.platform import platform

print "https://github.com/pixie-lang/external-deps/releases/download/1.0/externals-"+platform.name+".tar.bz2"